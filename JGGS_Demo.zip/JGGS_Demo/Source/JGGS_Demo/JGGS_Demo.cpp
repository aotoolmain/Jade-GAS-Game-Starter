// Fill out your copyright notice in the Description page of Project Settings.

#include "JGGS_Demo.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, JGGS_Demo, "JGGS_Demo" );
